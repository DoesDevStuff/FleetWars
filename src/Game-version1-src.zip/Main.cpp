/*
 * Main.cpp
 *
 *  Created on: 27 Feb 2024
 *      Author: Charlie
 */

#include "../src/headers/MainController.h"

int main() {
	MainController game;
	game.playGame();
    return 0;
}
